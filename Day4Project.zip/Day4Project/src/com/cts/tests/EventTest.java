package com.cts.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;

public class EventTest {

	private BookingDao dao;
	@Before
	public void setUp() throws Exception {
		dao=new BookingDao();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		assertTrue(dao.InsertLocations());
		
	}

}
