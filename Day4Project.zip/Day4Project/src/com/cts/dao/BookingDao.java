package com.cts.dao;

import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Booking;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class BookingDao {
private SessionFactory factory;
private Session session;
private Location location;
private Event event;
private Customer customer;
public BookingDao()
{
	factory=HibernateUtil.GetFactory();
}

public boolean InsertLocations()
{
	boolean status=false;
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	session.beginTransaction();
	Random random=new Random();
	Location location=null;
	try
	{
	for(int i=0;i<100;i++)
	{
		location=new Location();
		location.setLocationName("CTS"+random.nextInt(1000));
		session.save(location);
		
		
		if(i%20==0)
		{
			session.flush();
			session.clear();
		}
	}
	session.getTransaction().commit();
	status=true;
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	
	return status;
}


public int InsertLocation(Location loc)
{
	location=loc;	
	int pk=0;
	session=factory.openSession();
	session.beginTransaction();
	try
	{
	pk=(int) session.save(location);
	
	session.getTransaction().commit();
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	return pk;
}

public void InsertEvent(Event eve,int locationId)
{
	event=eve;
	session=factory.openSession();
	Location result=(Location) session.get(Location.class, locationId);
	session.beginTransaction();
	try
	{
	event.setLocation(result);
	session.persist(event);
	session.getTransaction().commit();
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	
}

public void InsertBooking(Booking book)
{
	
}
public void InsertCustomer(Customer cust)
{
	
}
}
