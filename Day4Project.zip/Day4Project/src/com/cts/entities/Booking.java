package com.cts.entities;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="CTS_Booking")
public class Booking {
	/*@AttributeOverride(name="customer", column=@Column(name="Cts_Cust_Id"))*/
	@EmbeddedId
	private BookingC bookingId;
	@Column(name="Tickets_Booked")
	private int ticketsBooked;
	@Column(name="Amount")
	private int amount;
	public BookingC getBookingId() {
		return bookingId;
	}
	public void setBookingId(BookingC bookingId) {
		this.bookingId = bookingId;
	}
	public int getTicketsBooked() {
		return ticketsBooked;
	}
	public void setTicketsBooked(int ticketsBooked) {
		this.ticketsBooked = ticketsBooked;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
}
